# PillPing

Medicine reminders that a 70-year-old can actually use, plus a live dashboard so the family stops wondering "did Dad take his pills?"

Built for the CareCircle Code-a-thon. The senior gets one huge button. The caregiver gets a real-time view and an urgent alert if a dose goes unconfirmed for 30 minutes.

| Senior's reminder | Confirmed |
|---|---|
| ![Reminder](docs/screenshots/senior-reminder.png) | ![Confirmed](docs/screenshots/senior-success.png) |

![Missed dose on the caregiver dashboard](docs/screenshots/caregiver-missed-dose.png)

![Weekly report](docs/screenshots/caregiver-weekly-report.png)

## Run it

You need Node 18 or newer. There is nothing to install: no `npm install`, no build step.

```bash
npm start
```

Then open <http://localhost:3000>. To use another port: `PORT=4000 npm start` (on Windows PowerShell: `$env:PORT=4000; npm start`).

Run the tests with `npm test`.

## The 90 second demo

1. Open the home page and pick **Ramesh Rao** under "I am taking the medicine". Open the caregiver dashboard for Ramesh in a second window and put them side by side.
2. On the senior screen, tap **Turn on reminders** once (browsers only allow sound after a tap).
3. In the caregiver window open **Demo controls** at the bottom, choose *Amlodipine* and press **Send reminder now**.
4. The senior screen fills with the reminder, a chime plays and the instructions are read aloud. Press **I Took My Medicine**.
5. The senior screen turns green: "Good Job, Dad!". The caregiver dashboard updates instantly: "Amlodipine taken at 10:01 AM".
6. Now show the failure case. Send another reminder, ignore it, and press **Skip ahead 31 minutes**. The caregiver gets a red "MISSED" banner with a Call button (and the server console prints the simulated SMS).
7. Back on the senior screen, tap **I Already Took It** to show the retroactive confirmation. The alert resolves.
8. Open the **Weekly report** tab for the adherence rings and the 14-day calendar.

Press **Reset demo data** in the demo controls to start over.

## What is in it

**Must-have features**

- Senior UI: very large type, pill pictures with shape and colour, every button at least 64px (the main ones are 100px+), no swipes or pinches, light and dark high-contrast themes, three text sizes.
- Medicine configurator: name, dose, time of day (morning, afternoon, night, each with its own time), food instructions, refill count, pill colour and shape.
- Full-screen reminder with **I Took My Medicine**, **Snooze 15 Mins**, and **I Already Took It** once a dose is late.
- Caregiver portal: today's doses as taken, pending or missed, updated live over server-sent events.
- Missed-dose escalation after 30 minutes with no confirmation (the grace window), shown as a red banner and a simulated SMS.
- Weekly scorecard: doses taken and doses taken on time (within 30 minutes), each compared with the week before, plus a 14-day calendar with green, amber and red dots.

**Stretch features**

- Voice read-aloud with the Web Speech API, in English, Hindi and Telugu (the sentence is translated, the medicine name is read as written).
- Pill bottle photo: caregivers upload one in the configurator and it replaces the pill drawing on the reminder.
- Refill warning when fewer than 5 doses are left.
- Emergency SOS: a red button that alerts the caregiver and offers one-tap calls to family or the ambulance (108).

## How it works

```
server.js          HTTP server, REST routes, server-sent events, 5 second escalation timer
src/doses.js       All the medication rules (grace window, snooze, refill, adherence)
src/seed.js        Two patients, four medicines each, 14 days of history
src/store.js       JSON file storage with atomic writes
src/validate.js    Input checking for the medicine form
src/clock.js       "Now", with an offset the demo controls can move
public/            The three pages and their scripts, no framework
test/              Unit tests for the rules above (npm test)
```

Some decisions worth knowing about:

- **The grace window is measured from the original time.** Snoozing moves the reminder, not the escalation. A dose snoozed at 10:05 still alerts the family at 10:30.
- **"I Already Took It" is a normal confirmation.** It is allowed on pending and missed doses, it resolves the earlier alert, and it counts as taken but not on time. The senior is never told off for forgetting to tap.
- **Reminders keep time in background tabs.** The page's tick comes from a Web Worker, whose timers are not throttled like page timers, and a desktop notification fires if the tab is hidden.
- **Demo clock.** The server's "now" can be moved forward from the demo controls so the 30 minute rule can be shown live. It never touches the real system clock and resets on restart.
- **Text size and theme are saved per device**, because a caregiver on a laptop and a parent on a phone need different settings.

### Where this differs from the suggested stack

The brief suggests Express and SQLite. This project uses Node's built-in `http` module and a JSON file instead, so it runs anywhere with zero installs and zero native builds. The data is a few hundred rows and the logic is isolated in `src/doses.js`, so swapping the storage in `src/store.js` for SQLite is a small change.

## API

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/patients` | List patients |
| GET | `/api/patients/:id/today` | Today's doses with live status |
| GET | `/api/patients/:id/adherence` | Weekly scores and 14-day calendar |
| GET | `/api/patients/:id/alerts` | Alert feed |
| GET / POST | `/api/patients/:id/meds` | List or add medicines |
| PUT / DELETE | `/api/meds/:id` | Edit or remove a medicine |
| POST | `/api/meds/:id/refill` | Add doses to the stock |
| POST | `/api/doses/:id/take` | Confirm a dose (`{ "selfReported": true }` for "already took it") |
| POST | `/api/doses/:id/snooze` | Snooze 15 minutes |
| POST | `/api/alerts/:id/ack` | Caregiver acknowledges an alert |
| POST | `/api/patients/:id/sos` | Emergency button |
| GET | `/api/events` | Server-sent events stream (live updates) |
| POST | `/api/demo/trigger`, `/advance`, `/reset` | Demo controls |

## Known limits

- Notifications and sounds need the page to be open (a minimised or background tab is fine, a closed browser is not). Reaching a closed browser would need a service worker with push, which is the first thing to add for real use.
- The SMS to the caregiver is simulated: it is printed in the server console. Twilio or a push service would plug into `dispatch()` in `server.js`.
- Voice quality depends on the voices installed on the device. If there is no Telugu voice, the browser falls back to its default voice.
- There are no logins. It is a demo: anyone who opens the page can act as the senior or the caregiver.
- This is a reminder tool, not medical advice. Medicine schedules should always follow the prescribing doctor's instructions.

## Put it on GitHub

1. Make an account at <https://github.com> and install Git from <https://git-scm.com/downloads>.
2. Tell Git who you are (once per computer):
   ```bash
   git config --global user.name "Your Name"
   git config --global user.email "you@example.com"
   ```
3. Unzip the project, open a terminal in the `pillping` folder and run:
   ```bash
   git init
   git add .
   git commit -m "PillPing: medicine reminders with a live caregiver dashboard"
   ```
4. On GitHub click **+** (top right), **New repository**. Name it `pillping`, leave "Add a README" **unticked** (you already have one), and click **Create repository**.
5. Copy the commands GitHub shows under "push an existing repository", or run these with your username filled in:
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/pillping.git
   git push -u origin main
   ```
6. If Git asks you to sign in, use the browser window it opens. If it asks for a password in the terminal, GitHub no longer accepts your account password: create a token at **Settings, Developer settings, Personal access tokens** with the `repo` permission and paste that instead.
7. Refresh the repository page: your files and screenshots should be there.

Shortcut with the GitHub CLI (`gh`): run `gh auth login`, then `gh repo create pillping --public --source=. --push` from the project folder.

To publish later changes: `git add .`, `git commit -m "what you changed"`, `git push`.

## License

MIT, see [LICENSE](LICENSE).
