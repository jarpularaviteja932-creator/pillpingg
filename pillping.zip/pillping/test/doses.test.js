const test = require('node:test');
const assert = require('node:assert/strict');

const D = require('../src/doses');
const { buildSeed } = require('../src/seed');
const { parseMedication } = require('../src/validate');
const { dateKey, at, shiftKey } = require('../src/dates');

const MIN = 60000;
const DAY = '2026-11-20';

// a fresh, small world: one patient, one morning pill at 10:00
function world(stock = 20) {
  const db = {
    patients: [{ id: 'p', name: 'Test Patient', callName: 'Dad' }],
    meds: [{
      id: 'm1', patientId: 'p', name: 'Amlodipine', dosage: '5 mg', food: 'any', color: 'pink', shape: 'round',
      schedule: [{ slot: 'morning', time: '10:00' }], stock, refillAlerted: stock < D.REFILL_BELOW, active: true,
    }],
    doses: [],
    alerts: [],
  };
  D.ensureDoses(db, DAY);
  return db;
}
const tenAm = at(DAY, '10:00');
const doseOf = (db) => db.doses[0];

test('ensureDoses creates each dose once', () => {
  const db = world();
  assert.equal(db.doses.length, 1);
  assert.equal(D.ensureDoses(db, DAY), 0);
  assert.equal(db.doses.length, 1);
});

test('nothing escalates before the 30 minute mark', () => {
  const db = world();
  assert.equal(D.tick(db, tenAm + 29 * MIN).length, 0);
  assert.equal(doseOf(db).status, 'pending');
});

test('an unconfirmed dose becomes a missed alert at 30 minutes, exactly once', () => {
  const db = world();
  const first = D.tick(db, tenAm + 30 * MIN);
  assert.equal(first.length, 1);
  assert.equal(first[0].type, 'missed');
  assert.equal(first[0].severity, 'urgent');
  assert.equal(doseOf(db).status, 'missed');
  assert.equal(D.tick(db, tenAm + 45 * MIN).length, 0);
  assert.equal(db.alerts.length, 1);
});

test('taking a dose on time records it and tells the caregiver', () => {
  const db = world();
  const res = D.takeDose(db, doseOf(db).id, tenAm + MIN);
  assert.equal(doseOf(db).status, 'taken');
  assert.equal(doseOf(db).onTime, true);
  assert.equal(res.alerts[0].type, 'taken');
  assert.equal(db.meds[0].stock, 19);
});

test('confirming twice does not double count or double alert', () => {
  const db = world();
  D.takeDose(db, doseOf(db).id, tenAm + MIN);
  const again = D.takeDose(db, doseOf(db).id, tenAm + 2 * MIN);
  assert.equal(again.duplicate, true);
  assert.equal(db.meds[0].stock, 19);
  assert.equal(db.alerts.length, 1);
});

test('retroactive confirmation resolves the missed alert and counts as late', () => {
  const db = world();
  D.tick(db, tenAm + 31 * MIN);
  const res = D.takeDose(db, doseOf(db).id, tenAm + 50 * MIN, { selfReported: true });
  const missed = db.alerts.find((a) => a.type === 'missed');
  assert.equal(missed.resolved, true);
  assert.equal(doseOf(db).onTime, false);
  assert.equal(doseOf(db).selfReported, true);
  assert.equal(res.alerts[0].type, 'late');
  assert.equal(D.stateOf(doseOf(db), tenAm + 60 * MIN), 'late');
});

test('snooze delays the reminder but not the escalation clock', () => {
  const db = world();
  const now = tenAm + 5 * MIN;
  D.snoozeDose(db, doseOf(db).id, now);
  assert.equal(D.stateOf(doseOf(db), now + MIN), 'snoozed');
  assert.equal(D.stateOf(doseOf(db), now + 15 * MIN), 'due');
  assert.equal(D.dueAt(doseOf(db)), now + 15 * MIN);
  // still escalates 30 min after the ORIGINAL time
  assert.equal(D.tick(db, tenAm + 30 * MIN).length, 1);
});

test('cannot snooze a finished dose', () => {
  const db = world();
  D.takeDose(db, doseOf(db).id, tenAm);
  assert.equal(D.snoozeDose(db, doseOf(db).id, tenAm).code, 409);
});

test('refill warning fires when stock drops below 5, and only once', () => {
  const db = world(5);
  const res = D.takeDose(db, doseOf(db).id, tenAm);    // 5 -> 4
  assert.ok(res.alerts.some((a) => a.type === 'refill'));
  const nextDay = '2026-11-21';
  D.ensureDoses(db, nextDay);
  const next = db.doses.find((d) => d.date === nextDay);
  const res2 = D.takeDose(db, next.id, at(nextDay, '10:00'));   // 4 -> 3
  assert.ok(!res2.alerts.some((a) => a.type === 'refill'));
});

test('exactly 5 doses left does not warn', () => {
  const db = world(6);
  const res = D.takeDose(db, doseOf(db).id, tenAm);    // 6 -> 5
  assert.ok(!res.alerts.some((a) => a.type === 'refill'));
});

test('adding a refill clears the warning and re-arms it', () => {
  const db = world(5);
  D.takeDose(db, doseOf(db).id, tenAm);
  D.refillMed(db, 'm1', 30, tenAm);
  assert.equal(db.meds[0].stock, 34);
  assert.equal(db.meds[0].refillAlerted, false);
  assert.ok(db.alerts.filter((a) => a.type === 'refill').every((a) => a.resolved));
});

test('refill rejects nonsense counts', () => {
  const db = world();
  assert.equal(D.refillMed(db, 'm1', -3, 0).code, 400);
  assert.equal(D.refillMed(db, 'm1', 'abc', 0).code, 400);
  assert.equal(D.refillMed(db, 'nope', 5, 0).code, 404);
});

test('stock never goes negative', () => {
  const db = world(0);
  D.takeDose(db, doseOf(db).id, tenAm);
  assert.equal(db.meds[0].stock, 0);
});

test('adherence ignores doses that are still ahead of us', () => {
  const db = world();
  const early = at(DAY, '09:00');
  const a = D.adherence(db, 'p', early, 1);
  assert.equal(a.last7.total, 0);
  assert.equal(a.last7.takenPct, null);
});

test('adherence math: taken, on time and late are counted separately', () => {
  const db = world();
  D.ensureDoses(db, shiftKey(DAY, -1));
  D.ensureDoses(db, shiftKey(DAY, -2));
  const [today, yest, before] = [
    db.doses.find((d) => d.date === DAY),
    db.doses.find((d) => d.date === shiftKey(DAY, -1)),
    db.doses.find((d) => d.date === shiftKey(DAY, -2)),
  ];
  const now = at(DAY, '12:00');
  D.takeDose(db, today.id, today.scheduledAt + 2 * MIN);                       // on time
  D.takeDose(db, yest.id, yest.scheduledAt + 90 * MIN);                        // 90 min late, was still pending
  before.status = 'missed';                                                    // missed
  const a = D.adherence(db, 'p', now, 14);
  assert.equal(a.last7.total, 3);
  assert.equal(a.last7.taken, 2);
  assert.equal(a.last7.onTime, 1);
  assert.equal(a.last7.takenPct, 67);
  const states = a.days.slice(-3).map((d) => d.state);
  assert.deepEqual(states, ['red', 'green', 'green']);
});

test('seed data: 2 patients, 4 medicines each, 14 days of history', () => {
  const now = new Date(2026, 10, 20, 9, 40).getTime();
  const db = buildSeed(now);
  assert.equal(db.patients.length, 2);
  for (const p of db.patients) {
    assert.equal(db.meds.filter((m) => m.patientId === p.id).length, 4);
    const a = D.adherence(db, p.id, now, 14);
    assert.equal(a.days.length, 14);
    assert.ok(a.days.slice(0, 13).every((d) => d.doses.length > 0));
  }
});

test('seed data is stable between resets', () => {
  const now = new Date(2026, 10, 20, 9, 40).getTime();
  const a = buildSeed(now);
  const b = buildSeed(now);
  assert.deepEqual(a.doses.map((d) => d.status), b.doses.map((d) => d.status));
});

test('seed: a day boundary does not break the schedule', () => {
  const late = new Date(2026, 10, 20, 23, 55).getTime();
  const db = buildSeed(late);
  assert.ok(db.doses.every((d) => d.status !== 'pending'));
  D.tick(db, late + 10 * MIN);                       // now it is tomorrow
  assert.ok(db.doses.some((d) => d.date === dateKey(late + 10 * MIN)));
});

// ---- validation ----

const good = { name: ' Metformin ', dosage: '500 mg', food: 'with', stock: '30', schedule: [{ slot: 'morning', time: '08:30' }] };

test('validation accepts a normal medicine and tidies it up', () => {
  const { value, error } = parseMedication(good);
  assert.equal(error, undefined);
  assert.equal(value.name, 'Metformin');
  assert.equal(value.stock, 30);
});

test('validation explains what is missing', () => {
  assert.match(parseMedication({ ...good, name: '  ' }).error, /name/i);
  assert.match(parseMedication({ ...good, dosage: '' }).error, /dosage/i);
  assert.match(parseMedication({ ...good, schedule: [] }).error, /time of day/i);
  assert.match(parseMedication({ ...good, stock: -1 }).error, /between 0 and 999/);
  assert.match(parseMedication({ ...good, stock: 'lots' }).error, /between 0 and 999/);
});

test('validation drops unknown slots, bad times and duplicates', () => {
  const { value } = parseMedication({
    ...good,
    schedule: [{ slot: 'midnight', time: '00:00' }, { slot: 'night', time: '25:99' }, { slot: 'night', time: '21:00' }],
  });
  assert.deepEqual(value.schedule, [{ slot: 'night', time: '21:00' }]);
});

test('validation refuses non-image photos', () => {
  assert.match(parseMedication({ ...good, photo: 'data:text/html;base64,PGI+' }).error, /photo/i);
});
