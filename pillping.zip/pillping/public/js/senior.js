// The senior's screen. One job: make it very hard to miss a dose and very easy to confirm one.

(() => {
  const { h, api, fill, instructions } = PP;
  const params = new URLSearchParams(location.search);
  const pid = params.get('p') || localStorage.getItem('pp.patient') || 'p1';
  localStorage.setItem('pp.patient', pid);

  PP.applyPrefs('senior', 1);
  document.getElementById('prefs').append(PP.prefsBar('senior', 1));

  // What the voice says. Medicine names stay as written; the sentence around them is translated.
  const VOICE = {
    en: {
      remind: (m, who) => [`${who}, it is time for your ${m.name}, ${m.dosage}.`, m.note && `${m.note}.`,
        m.food === 'with' ? 'Take it with food.' : m.food === 'without' ? 'Take it on an empty stomach.' : ''].filter(Boolean).join(' '),
      good: (who) => `Good job, ${who}!`,
    },
    hi: {
      remind: (m, who) => `${who}, आपकी दवा लेने का समय हो गया है। ${m.name}, ${m.dosage}। ${m.food === 'with' ? 'इसे खाने के साथ लें।' : m.food === 'without' ? 'इसे खाली पेट लें।' : 'इसे पानी के साथ लें।'}`,
      good: () => 'शाबाश! बहुत अच्छा।',
    },
    te: {
      remind: (m) => `మీ మందు తీసుకునే సమయం అయింది. ${m.name}, ${m.dosage}. ${m.food === 'with' ? 'భోజనంతో పాటు తీసుకోండి.' : m.food === 'without' ? 'ఖాళీ కడుపుతో తీసుకోండి.' : 'నీటితో తీసుకోండి.'}`,
      good: () => 'చాలా బాగుంది!',
    },
  };

  let state = null;
  let refreshing = false;
  let tickCount = 0;
  let current = null;          // dose shown in the reminder overlay
  let chimeTimer = null;
  let busy = false;
  let successUntil = 0;
  let voiceOn = localStorage.getItem('pp.voice') !== 'off';
  const notified = new Set();  // doseId:dueAt pairs we already announced

  const $ = (id) => document.getElementById(id);
  const patient = () => state.patient;
  const voiceCopy = () => VOICE[patient().voiceLang.slice(0, 2)] || VOICE.en;
  const isPending = (d) => d.status === 'pending';
  const dueNow = (d) => isPending(d) && d.dueAt <= PP.nowMs();

  // ---- data -------------------------------------------------------------------
  async function refresh() {
    if (refreshing) return;
    refreshing = true;
    try {
      state = await api.get(`/api/patients/${pid}/today`);
      PP.syncClock(state.now);
      render();
      checkReminders();
    } catch (err) {
      fill($('next-card'), h('div', { class: 'banner urgent', role: 'alert' }, 'Cannot reach the server. Please ask your family for help.'));
    } finally {
      refreshing = false;
    }
  }

  // ---- main screen ------------------------------------------------------------
  function greeting() {
    const hr = new Date(PP.nowMs()).getHours();
    return hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
  }

  function paintClock() {
    const now = PP.nowMs();
    $('clock-time').textContent = PP.fmtTime(now);
    $('clock-date').textContent = PP.fmtDate(now);
  }

  function enableBanner() {
    const box = $('enable-banner');
    const needsSound = !PP.audioReady();
    const needsAlerts = PP.canNotify() && Notification.permission === 'default';
    if (!needsSound && !needsAlerts) return box.replaceChildren();
    box.replaceChildren(h('div', { class: 'banner' },
      h('span', {}, 'Tap here so reminders can make a sound and pop up.'),
      h('button', { class: 'btn btn-primary', type: 'button', onclick: async () => {
        PP.chime();
        await PP.askNotifyPermission();
        enableBanner();
      } }, 'Turn on reminders')));
  }

  function statusFor(d) {
    const now = PP.nowMs();
    if (d.status === 'taken') return { cls: 'is-taken', chip: h('span', { class: 'chip ok' }, '✓ Taken at ' + PP.fmtTime(d.takenAt)) };
    if (d.status === 'missed') return { cls: 'is-missed', chip: h('span', { class: 'chip bad' }, '! Not confirmed') };
    if (dueNow(d)) return { cls: 'is-due', chip: h('span', { class: 'chip warn' }, 'Time to take it now') };
    if (d.snoozedUntil && d.snoozedUntil > now) return { cls: '', chip: h('span', { class: 'chip warn' }, 'Reminder at ' + PP.fmtTime(d.snoozedUntil)) };
    return { cls: '', chip: h('span', { class: 'chip' }, 'Later today') };
  }

  async function markTaken(dose, selfReported) {
    if (busy) return;
    busy = true;
    try {
      await api.post(`/api/doses/${dose.id}/take`, { selfReported });
      showSuccess(dose);
      await refresh();
    } catch (err) {
      PP.toast(err.message);
    } finally {
      busy = false;
    }
  }

  function render() {
    const doses = state.doses;
    paintClock();
    document.title = `${greeting()}, ${patient().name.split(' ')[0]} | PillPing`;

    // the next card
    const next = doses.filter(isPending).sort((a, b) => a.dueAt - b.dueAt)[0];
    const nextCard = $('next-card');
    if (!next) {
      nextCard.replaceChildren(h('div', { class: 'card next' },
        h('h1', {}, `${greeting()}, ${patient().name.split(' ')[0]}`),
        h('p', { class: 'big' }, 'You are all done for today. Well done!')));
    } else {
      nextCard.replaceChildren(h('div', { class: 'card next' },
        h('h1', {}, `${greeting()}, ${patient().name.split(' ')[0]}`),
        h('div', { class: 'row' },
          PP.pillSvg(next.med.color, next.med.shape, 84),
          h('div', { class: 'grow' },
            h('div', { class: 'muted' }, 'Your next medicine'),
            h('div', { class: 'big' }, `${PP.fmtTime(next.dueAt)}: ${next.med.name}`),
            h('div', {}, `${next.med.dosage}. ${instructions(next.med).join('. ')}.`)))));
    }

    // the list
    $('dose-list').replaceChildren(...doses.map((d) => {
      const st = statusFor(d);
      const extra = [st.chip];
      if (d.status === 'missed') {
        extra.push(h('button', { class: 'btn btn-ok', type: 'button', onclick: () => markTaken(d, true) }, 'I Already Took It'));
      }
      return h('li', { class: `dose ${st.cls}` },
        PP.pillSvg(d.med.color, d.med.shape, 64),
        h('div', {},
          h('div', { class: 'when' }, `${PP.SLOT_LABEL[d.slot]}, ${PP.fmtTime(d.scheduledAt)}`),
          h('div', { class: 'what' }, `${d.med.name} ${d.med.dosage}`),
          h('div', { class: 'muted' }, instructions(d.med).join('. '))),
        h('div', { class: 'extra' }, extra));
    }));

    // the week
    const w = state.week;
    fill($('week-card'),
      h('h2', {}, 'Your week'),
      w.total
        ? h('p', { class: 'big' }, `${w.takenPct}% of your medicines taken`)
        : h('p', {}, 'Your first week is just starting.'),
      w.total ? h('p', { class: 'muted' }, `${w.taken} of ${w.total} doses. Your family can see how well you are doing.`) : null);

    enableBanner();
  }

  // ---- reminder overlay -------------------------------------------------------
  function reminderText(d) {
    return voiceCopy().remind(d.med, patient().callName);
  }

  function showReminder(dose, queued) {
    current = dose;
    const m = dose.med;
    const lateMin = Math.round((PP.nowMs() - dose.scheduledAt) / 60000);
    const el = $('reminder');

    const actions = [
      h('button', { class: 'btn btn-take', id: 'btn-take', type: 'button', onclick: () => takeFromReminder(false) }, 'I Took My Medicine'),
      h('button', { class: 'btn btn-snooze', type: 'button', onclick: snoozeFromReminder }, 'Snooze 15 Mins'),
    ];
    if (lateMin >= 5) {
      actions.push(h('button', { class: 'btn btn-link', type: 'button', onclick: () => takeFromReminder(true) }, 'I Already Took It'));
    }
    if ('speechSynthesis' in window) {
      actions.push(h('button', { class: 'btn btn-link', type: 'button', onclick: () => PP.speak(reminderText(dose), patient().voiceLang) }, 'Hear it again'));
    }

    fill(el,
      queued > 1 ? h('div', { class: 'counter' }, `${queued} medicines are due`) : null,
      h('div', { class: 'when', id: 'rem-title' }, PP.fmtTime(dose.scheduledAt)),
      m.purpose ? h('div', { class: 'purpose' }, m.purpose) : null,
      m.photoUrl
        ? h('img', { class: 'photo', src: m.photoUrl, alt: `Photo of the ${m.name} pill bottle` })
        : PP.pillSvg(m.color, m.shape, 88),
      h('div', { id: 'rem-desc' },
        h('div', { class: 'med-name' }, m.name),
        h('div', { class: 'dosage' }, m.dosage),
        h('div', { class: 'pill-words' }, PP.pillWords(m))),
      h('div', { class: 'instruction' }, instructions(m).map((line) => h('div', {}, line))),
      lateMin >= 5 ? h('div', { class: 'late-note' }, `This was due ${lateMin} minutes ago`) : null,
      h('div', { class: 'actions' }, actions));

    el.hidden = false;
    $('app-root').setAttribute('aria-hidden', 'true');
    $('btn-take').focus();

    // announce once per due moment, not on every refresh
    const key = `${dose.id}:${dose.dueAt}`;
    if (!notified.has(key)) {
      notified.add(key);
      PP.chime();
      if (voiceOn) setTimeout(() => PP.speak(reminderText(dose), patient().voiceLang), 1200);
      if (document.hidden) PP.notify(`Time for your ${m.name}`, `${m.dosage}. ${instructions(m).join('. ')}.`, dose.id);
    }
    clearInterval(chimeTimer);
    chimeTimer = setInterval(PP.chime, 30000);   // a gentle repeat until it is answered
  }

  function hideReminder() {
    current = null;
    clearInterval(chimeTimer);
    PP.stopSpeaking();
    $('reminder').hidden = true;
    if ($('success').hidden) $('app-root').removeAttribute('aria-hidden');
  }

  async function takeFromReminder(selfReported) {
    const dose = current;
    if (!dose) return;
    hideReminder();
    await markTaken(dose, selfReported);
  }

  async function snoozeFromReminder() {
    const dose = current;
    if (!dose || busy) return;
    busy = true;
    try {
      const res = await api.post(`/api/doses/${dose.id}/snooze`);
      hideReminder();
      PP.toast(`OK. I will remind you again at ${PP.fmtTime(res.dose.snoozedUntil)}.`, 5000);
      await refresh();
    } catch (err) {
      PP.toast(err.message);
    } finally {
      busy = false;
    }
  }

  function checkReminders() {
    if (!state || Date.now() < successUntil) return;
    const due = state.doses.filter(dueNow).sort((a, b) => a.dueAt - b.dueAt);
    if (!due.length) {
      if (current) hideReminder();
      return;
    }
    if (current && due[0].id === current.id) return;   // already showing the right one
    showReminder(due[0], due.length);
  }

  // ---- success ----------------------------------------------------------------
  function showSuccess(dose) {
    const el = $('success');
    const who = patient().callName;
    const copy = voiceCopy();
    const check = h('span', { 'aria-hidden': 'true' });
    check.innerHTML = '<svg class="check" viewBox="0 0 120 120"><circle cx="60" cy="60" r="54" fill="none" stroke="currentColor" stroke-width="8"/><path d="M34 62l17 17 36-38" fill="none" stroke="currentColor" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    el.replaceChildren(
      check,
      h('h1', { id: 'ok-title' }, `Good Job, ${who}!`),
      h('p', {}, `${dose.med.name} ${dose.med.dosage} is marked as taken.`),
      h('p', {}, `${patient().caregiver.name} has been told.`),
      h('button', { class: 'btn btn-block', type: 'button', style: 'max-width:420px;background:var(--bg);color:var(--fg)', onclick: closeSuccess }, 'OK'));
    el.hidden = false;
    el.querySelector('button').focus();
    successUntil = Date.now() + 4500;
    if (voiceOn) PP.speak(copy.good(who), patient().voiceLang);
    clearTimeout(showSuccess.timer);
    showSuccess.timer = setTimeout(closeSuccess, 4500);
  }

  function closeSuccess() {
    clearTimeout(showSuccess.timer);
    successUntil = 0;
    $('success').hidden = true;
    $('app-root').removeAttribute('aria-hidden');
    checkReminders();   // if another medicine is waiting, show it next
  }

  // ---- SOS --------------------------------------------------------------------
  const sos = $('sos-dialog');
  $('sos-open').addEventListener('click', async () => {
    const p = patient();
    $('sos-call-family').href = `tel:${p.caregiver.phone}`;
    $('sos-call-family').textContent = `Call ${p.caregiver.name} (${p.caregiver.relation.toLowerCase()})`;
    $('sos-call-ambulance').href = `tel:${p.emergencyNumber}`;
    $('sos-call-ambulance').textContent = `Call ambulance (${p.emergencyNumber})`;
    sos.showModal();
    try { await api.post(`/api/patients/${pid}/sos`); } catch { $('sos-note').textContent = 'Could not alert your family automatically. Please call them now.'; }
  });
  $('sos-close').addEventListener('click', () => sos.close());

  // ---- voice on/off -----------------------------------------------------------
  if ('speechSynthesis' in window) {
    const voiceBtn = h('button', { class: 'btn btn-outline', type: 'button', style: 'font-size:1rem;padding:0.3rem 0.9rem' });
    const paintVoice = () => { voiceBtn.textContent = voiceOn ? 'Voice: On' : 'Voice: Off'; voiceBtn.setAttribute('aria-pressed', String(voiceOn)); };
    voiceBtn.addEventListener('click', () => {
      voiceOn = !voiceOn;
      localStorage.setItem('pp.voice', voiceOn ? 'on' : 'off');
      if (!voiceOn) PP.stopSpeaking();
      paintVoice();
    });
    paintVoice();
    document.querySelector('#prefs .prefs').append(voiceBtn);
  }

  // ---- start ------------------------------------------------------------------
  PP.backgroundTicker(1000, () => {
    if (!state) return;
    tickCount++;
    paintClock();
    checkReminders();
    if (tickCount % 5 === 0) refresh();   // belt and braces next to the live connection
  });
  PP.liveUpdates(refresh);
  window.addEventListener('pointerdown', () => setTimeout(enableBanner, 50), { once: true });
  refresh();
})();
