// The caregiver dashboard: what happened, what is pending, what needs attention.

(() => {
  const { h, api } = PP;
  const params = new URLSearchParams(location.search);
  let pid = params.get('p') || localStorage.getItem('pp.patient') || 'p1';

  PP.applyPrefs('caregiver', 0);
  document.getElementById('prefs').append(PP.prefsBar('caregiver', 0));

  const $ = (id) => document.getElementById(id);
  let patients = [];
  let data = { today: null, adh: null, alerts: null, meds: null };
  let seenAlerts = null;       // null until the first load, so old alerts don't ring on page open
  let activeTab = 'today';
  let refreshing = false;

  const TABS = [
    ['today', 'Today'],
    ['week', 'Weekly report'],
    ['meds', 'Medicines'],
    ['alerts', 'Alerts'],
  ];

  // ---- loading ----------------------------------------------------------------
  async function refresh() {
    if (refreshing) return;
    refreshing = true;
    try {
      const [today, adh, alerts, meds] = await Promise.all([
        api.get(`/api/patients/${pid}/today`),
        api.get(`/api/patients/${pid}/adherence`),
        api.get(`/api/patients/${pid}/alerts`),
        api.get(`/api/patients/${pid}/meds`),
      ]);
      data = { today, adh, alerts, meds };
      PP.syncClock(today.now);
      announceNewAlerts(alerts.alerts);
      render();
    } catch (err) {
      PP.toast('Could not refresh: ' + err.message);
    } finally {
      refreshing = false;
    }
  }

  function announceNewAlerts(list) {
    const ids = new Set(list.map((a) => a.id));
    if (seenAlerts) {
      for (const a of list) {
        if (seenAlerts.has(a.id) || a.ack) continue;
        const text = alertText(a);
        if (a.severity === 'urgent') PP.alarm();
        PP.notify(text.title, text.detail, a.id);
      }
    }
    seenAlerts = ids;
  }

  // ---- text for alerts --------------------------------------------------------
  function alertText(a) {
    const name = data.today ? data.today.patient.callName : 'Your family member';
    const med = a.medName ? `${a.medName} ${a.dosage}` : '';
    switch (a.type) {
      case 'taken': return { icon: '✓', tone: 'ok', title: `${a.medName} taken at ${PP.fmtTime(a.at)}`, detail: `${name} confirmed ${med} (due ${PP.fmtTime(a.scheduledAt)}).` };
      case 'late': return { icon: '✓', tone: 'warn', title: `${a.medName} taken late, confirmed at ${PP.fmtTime(a.at)}`, detail: `${name} said ${med} was taken after the 30 minute window (due ${PP.fmtTime(a.scheduledAt)}).` };
      case 'missed': return { icon: '!', tone: 'bad', title: `MISSED: ${med}`, detail: `Due at ${PP.fmtTime(a.scheduledAt)} and not confirmed after 30 minutes.` };
      case 'refill': return { icon: '○', tone: 'warn', title: `Refill needed: ${a.medName}`, detail: `Only ${a.stock} dose${a.stock === 1 ? '' : 's'} left.` };
      case 'sos': return { icon: 'SOS', tone: 'bad', title: `${name} pressed the emergency button`, detail: 'Please call right away.' };
      default: return { icon: '?', tone: '', title: 'Notification', detail: '' };
    }
  }

  // ---- layout -----------------------------------------------------------------
  function paintTabs() {
    const open = data.alerts ? data.alerts.alerts.filter((a) => !a.ack && a.severity !== 'ok').length : 0;
    $('tabs').replaceChildren(...TABS.map(([key, label]) => h('button', {
      class: 'btn tab', type: 'button', role: 'tab', id: `tab-${key}`,
      'aria-selected': String(activeTab === key), 'aria-controls': `panel-${key}`,
      onclick: () => { activeTab = key; paintTabs(); showPanel(); },
    }, label, key === 'alerts' && open ? h('span', { class: 'badge', 'aria-label': `${open} need attention` }, String(open)) : null)));
  }

  function showPanel() {
    for (const [key] of TABS) $(`panel-${key}`).hidden = key !== activeTab;
  }

  function render() {
    const p = data.today.patient;
    $('who').textContent = `Watching over ${p.name}`;
    $('who-sub').textContent = `${p.age} years. ${p.conditions.join(', ')}.`;
    document.title = `${p.callName}'s medicines | PillPing`;
    renderBanners();
    renderToday();
    renderWeek();
    renderMeds();
    renderAlerts();
    renderDemoSelect();
    paintTabs();
    showPanel();
    soundBanner();
    $('demo-clock').textContent = `Server time: ${PP.fmtTime(PP.nowMs())}`;
  }

  function soundBanner() {
    const box = $('sound-banner');
    const need = !PP.audioReady() || (PP.canNotify() && Notification.permission === 'default');
    if (!need) return box.replaceChildren();
    box.replaceChildren(h('div', { class: 'banner' },
      h('span', {}, 'Turn on alerts so this page can beep and pop up when a dose is missed.'),
      h('button', { class: 'btn btn-primary', type: 'button', onclick: async () => { PP.chime(); await PP.askNotifyPermission(); soundBanner(); } }, 'Turn on alerts')));
  }

  // red banners for anything urgent nobody has acknowledged yet
  function renderBanners() {
    const urgent = data.alerts.alerts.filter((a) => a.severity === 'urgent' && !a.ack && !a.resolved);
    $('alert-banners').replaceChildren(...urgent.map((a) => {
      const t = alertText(a);
      return h('div', { class: 'banner urgent', role: 'alert' },
        h('div', {}, h('strong', {}, t.title), h('div', {}, `${t.detail} (${PP.ago(a.at, PP.nowMs())})`)),
        h('div', { class: 'row' },
          h('a', { class: 'btn btn-bad', href: `tel:${data.today.patient.caregiver.phone}` }, `Call ${data.today.patient.callName}`),
          h('button', { class: 'btn btn-outline', type: 'button', onclick: async () => { await api.post(`/api/alerts/${a.id}/ack`); refresh(); } }, 'I have seen this')));
    }));
  }

  // ---- today ------------------------------------------------------------------
  function renderToday() {
    const doses = data.today.doses;
    const count = (s) => doses.filter((d) => s.includes(d.state)).length;
    const taken = count(['taken', 'late']);
    const missed = count(['missed']);
    const waiting = count(['upcoming', 'due', 'snoozed']);

    const items = doses.map((d) => {
      let tone = '', icon = '○', title, sub;
      const m = d.med;
      switch (d.state) {
        case 'taken':
          tone = 'ok'; icon = '✓';
          title = `${m.name} taken at ${PP.fmtTime(d.takenAt)}`;
          sub = `${m.dosage}. Scheduled ${PP.fmtTime(d.scheduledAt)}.`;
          break;
        case 'late':
          tone = 'warn'; icon = '✓';
          title = `${m.name} confirmed late, at ${PP.fmtTime(d.takenAt)}`;
          sub = `${m.dosage}. Scheduled ${PP.fmtTime(d.scheduledAt)}${d.selfReported ? ', reported as already taken' : ''}.`;
          break;
        case 'missed':
          tone = 'bad'; icon = '!';
          title = `${m.name} NOT confirmed`;
          sub = `${m.dosage}. Was due ${PP.fmtTime(d.scheduledAt)}, ${PP.ago(d.scheduledAt, PP.nowMs())}.`;
          break;
        case 'due': {
          tone = 'warn'; icon = '⏰';
          const left = Math.max(0, 30 - Math.floor((PP.nowMs() - d.scheduledAt) / 60000));
          title = `${m.name} due now`;
          sub = `${m.dosage}. Reminder is on ${patientName()}'s screen. Alert in ${left} min if unconfirmed.`;
          break;
        }
        case 'snoozed':
          tone = 'warn'; icon = '⏰';
          title = `${m.name} snoozed`;
          sub = `Reminder returns at ${PP.fmtTime(d.snoozedUntil)}.`;
          break;
        default:
          title = `${m.name} at ${PP.fmtTime(d.scheduledAt)}`;
          sub = `${m.dosage}. ${PP.SLOT_LABEL[d.slot]}.`;
      }
      return h('li', { class: `tl ${tone}` },
        h('span', { class: 'icon', 'aria-hidden': 'true' }, icon),
        h('div', {},
          h('div', { class: 'title' }, title),
          h('div', { class: 'sub' }, sub)),
        d.state === 'missed'
          ? h('a', { class: 'btn btn-bad', href: `tel:${data.today.patient.caregiver.phone}` }, `Call ${patientName()}`)
          : PP.pillSvg(m.color, m.shape, 44));
    });

    $('panel-today').replaceChildren(
      h('div', { class: 'tiles' },
        tile(taken, 'taken today', 'ok'),
        tile(waiting, 'still to come', ''),
        tile(missed, 'not confirmed', missed ? 'bad' : '')),
      h('h2', {}, `${patientName()}'s day`),
      doses.length ? h('ul', { class: 'timeline' }, items) : h('p', {}, 'No medicines are scheduled today.'));
  }

  const patientName = () => data.today.patient.callName;
  const tile = (n, label, cls) => h('div', { class: `tile ${cls}` }, h('div', { class: 'num' }, String(n)), h('div', {}, label));

  // ---- weekly report ----------------------------------------------------------
  function ring(pct) {
    const r = 70, c = 2 * Math.PI * r;
    const val = pct == null ? 0 : pct;
    const color = pct == null ? 'var(--muted)' : pct >= 90 ? 'var(--ok)' : pct >= 75 ? 'var(--warn)' : 'var(--bad)';
    const wrap = document.createElement('div');
    wrap.innerHTML = `<svg class="ring" viewBox="0 0 180 180" role="img" aria-label="${pct == null ? 'No data yet' : pct + ' percent'}">
      <circle cx="90" cy="90" r="${r}" fill="none" stroke="var(--line)" stroke-opacity=".2" stroke-width="16"/>
      <circle cx="90" cy="90" r="${r}" fill="none" stroke="${color}" stroke-width="16" stroke-linecap="round"
        stroke-dasharray="${(c * val) / 100} ${c}" transform="rotate(-90 90 90)"/>
      <text x="90" y="102" text-anchor="middle" font-size="40">${pct == null ? '--' : pct + '%'}</text></svg>`;
    return wrap.firstElementChild;
  }

  function trend(now, before, label) {
    if (now == null || before == null) return h('p', { class: 'muted' }, 'Not enough history to compare yet.');
    const diff = now - before;
    if (diff === 0) return h('p', { class: 'muted' }, `Same as the week before (${before}%).`);
    return h('p', { class: 'muted' }, `${Math.abs(diff)} points ${diff > 0 ? 'better' : 'lower'} than the week before (${before}%).`);
  }

  function renderWeek() {
    const a = data.adh;
    const w = a.last7;
    const days = a.days;

    const cells = days.map((d) => {
      const dt = new Date(d.date + 'T12:00:00');
      const isToday = d.date === days[days.length - 1].date;
      return h('div', { class: `day ${d.state === 'none' ? '' : d.state}`, role: 'group',
        'aria-label': `${dt.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}: ${dayWords(d)}` },
        h('div', { class: 'dow' }, isToday ? 'Today' : dt.toLocaleDateString('en-IN', { weekday: 'short' })),
        h('div', { class: 'dom' }, String(dt.getDate())),
        h('div', { class: 'dots' }, d.doses.map((x) => h('span', { class: `dot ${x.state}`, title: `${x.medName}: ${x.state}` }))));
    });

    $('panel-week').replaceChildren(
      h('div', { class: 'score-grid' },
        h('div', { class: 'card' },
          h('h2', {}, 'Doses taken, last 7 days'),
          h('div', { class: 'row' }, ring(w.takenPct),
            h('div', { class: 'grow' },
              h('p', { class: 'big' }, w.total ? `${w.taken} of ${w.total} doses` : 'No doses yet'),
              trend(w.takenPct, a.prev7.takenPct))))
        ,
        h('div', { class: 'card' },
          h('h2', {}, 'Taken on time'),
          h('div', { class: 'row' }, ring(w.onTimePct),
            h('div', { class: 'grow' },
              h('p', { class: 'big' }, w.total ? `${w.onTime} of ${w.total} within 30 min` : 'No doses yet'),
              trend(w.onTimePct, a.prev7.onTimePct))))),
      h('div', { class: 'card' },
        h('h2', {}, 'Last 2 weeks'),
        h('div', { class: 'calendar' }, cells.slice(0, 7)),
        h('div', { class: 'calendar', style: 'margin-top:0.5rem' }, cells.slice(7)),
        h('div', { class: 'legend' },
          h('span', {}, h('i', { class: 'dot taken' }), 'Taken on time'),
          h('span', {}, h('i', { class: 'dot late' }), 'Taken late'),
          h('span', {}, h('i', { class: 'dot missed' }), 'Missed'),
          h('span', {}, h('i', { class: 'dot' }), 'Still to come'))));
  }

  function dayWords(d) {
    if (!d.doses.length) return 'no medicines';
    const n = (s) => d.doses.filter((x) => x.state === s).length;
    return `${n('taken')} on time, ${n('late')} late, ${n('missed')} missed`;
  }

  // ---- medicines (the configurator) -------------------------------------------
  function foodWords(f) { return PP.FOOD_TEXT[f]; }

  function renderMeds() {
    const meds = data.meds;
    $('panel-meds').replaceChildren(
      h('div', { class: 'row', style: 'justify-content:space-between;flex-wrap:wrap;margin-bottom:0.8rem' },
        h('h2', { style: 'margin:0' }, `${patientName()}'s medicines`),
        h('button', { class: 'btn btn-primary', type: 'button', onclick: () => openMedForm() }, '+ Add a medicine')),
      h('div', { class: 'dose-list' }, meds.map((m) => {
        const pct = Math.min(100, Math.round((m.stock / 30) * 100));
        return h('article', { class: 'med-card' },
          m.photoUrl ? h('img', { src: m.photoUrl, alt: `Photo of ${m.name}`, class: 'photo-preview', style: 'width:84px;height:84px;object-fit:cover' }) : PP.pillSvg(m.color, m.shape, 72),
          h('div', {},
            h('div', { class: 'what', style: 'font-size:1.3rem;font-weight:800' }, `${m.name} ${m.dosage}`),
            h('div', { class: 'muted' }, [m.purpose, foodWords(m.food)].filter(Boolean).join('. ')),
            h('div', {}, m.schedule.map((s) => `${PP.SLOT_LABEL[s.slot]} ${PP.fmtTime(new Date(`2000-01-01T${s.time}`).getTime())}`).join(' and ')),
            h('div', { class: m.lowStock ? 'chip low' : 'muted', style: 'margin-top:0.3rem' }, `${m.stock} doses left${m.lowStock ? ' (refill soon)' : ''}`),
            h('div', { class: `meter ${m.lowStock ? 'low' : ''}`, 'aria-hidden': 'true' }, h('i', { style: `width:${pct}%` }))),
          h('div', { class: 'btns' },
            h('button', { class: 'btn btn-small', type: 'button', onclick: () => openMedForm(m) }, 'Edit'),
            h('button', { class: 'btn btn-small', type: 'button', onclick: () => openRefill(m) }, 'Add refill'),
            h('button', { class: 'btn btn-small btn-outline', type: 'button', onclick: () => removeMed(m) }, 'Remove')));
      })));
  }

  async function removeMed(m) {
    if (!confirm(`Remove ${m.name} from ${patientName()}'s schedule? Past records are kept.`)) return;
    try { await api.del(`/api/meds/${m.id}`); PP.toast(`${m.name} removed.`); refresh(); } catch (e) { PP.toast(e.message); }
  }

  function openRefill(m) {
    const dlg = $('refill-dialog');
    const input = h('input', { type: 'number', id: 'refill-count', min: '1', max: '999', value: '30', inputmode: 'numeric' });
    const err = h('div', { class: 'form-error', role: 'alert' });
    dlg.replaceChildren(h('form', { method: 'dialog', onsubmit: async (e) => {
      e.preventDefault();
      try { await api.post(`/api/meds/${m.id}/refill`, { count: input.value }); dlg.close(); PP.toast(`${m.name} stock updated.`); refresh(); }
      catch (ex) { err.textContent = ex.message; }
    } },
      h('h2', { id: 'refill-title' }, `Add a refill of ${m.name}`),
      h('div', { class: 'field' }, h('label', { for: 'refill-count' }, 'How many doses were added?'), input),
      err,
      h('div', { class: 'row', style: 'flex-wrap:wrap' },
        h('button', { class: 'btn btn-primary', type: 'submit' }, 'Save'),
        h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Cancel'))));
    dlg.showModal();
  }

  // downsizes a chosen photo so it stays small enough to store
  function readPhoto(file) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        const scale = Math.min(1, 480 / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        URL.revokeObjectURL(url);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = () => reject(new Error('That file could not be read as an image.'));
      img.src = url;
    });
  }

  function openMedForm(med) {
    const dlg = $('med-dialog');
    const editing = !!med;
    const v = med || { name: '', dosage: '', purpose: '', food: 'any', note: '', color: 'white', shape: 'round', stock: 30, schedule: [{ slot: 'morning', time: '09:00' }] };
    const defaults = { morning: '09:00', afternoon: '14:00', night: '21:00' };
    let photoData;      // undefined = unchanged
    let removePhoto = false;

    const err = h('div', { class: 'form-error', role: 'alert' });
    const text = (id, label, value, extra = {}) => h('div', { class: 'field' }, h('label', { for: id }, label), h('input', { type: 'text', id, value, ...extra }));

    const slotRows = Object.keys(defaults).map((slot) => {
      const existing = v.schedule.find((s) => s.slot === slot);
      return h('div', { class: 'check-row' },
        h('input', { type: 'checkbox', id: `slot-${slot}`, checked: !!existing }),
        h('label', { for: `slot-${slot}` }, PP.SLOT_LABEL[slot]),
        h('input', { type: 'time', id: `time-${slot}`, value: existing ? existing.time : defaults[slot], 'aria-label': `${PP.SLOT_LABEL[slot]} time` }));
    });

    const foodRows = [['with', 'With food'], ['without', 'Without food (empty stomach)'], ['any', 'No food rule']].map(([val, label]) =>
      h('div', { class: 'check-row' }, h('input', { type: 'radio', name: 'food', id: `food-${val}`, value: val, checked: v.food === val }), h('label', { for: `food-${val}` }, label)));

    const colorSel = h('select', { id: 'f-color' }, Object.keys(PP.PILL_COLORS).map((c) => h('option', { value: c, selected: v.color === c }, PP.PILL_NAMES[c])));
    const shapeSel = h('select', { id: 'f-shape' }, [['round', 'Round tablet'], ['oval', 'Oval tablet'], ['capsule', 'Capsule']].map(([s, l]) => h('option', { value: s, selected: v.shape === s }, l)));
    const preview = h('div', { 'aria-hidden': 'true' });
    const paintPreview = () => preview.replaceChildren(PP.pillSvg(colorSel.value, shapeSel.value, 64));
    colorSel.addEventListener('change', paintPreview);
    shapeSel.addEventListener('change', paintPreview);
    paintPreview();

    const photoShow = h('div', {}, med && med.photoUrl ? h('img', { class: 'photo-preview', src: med.photoUrl, alt: 'Current bottle photo' }) : null);
    const photoInput = h('input', { type: 'file', id: 'f-photo', accept: 'image/*' });
    photoInput.addEventListener('change', async () => {
      if (!photoInput.files[0]) return;
      try {
        photoData = await readPhoto(photoInput.files[0]);
        removePhoto = false;
        photoShow.replaceChildren(h('img', { class: 'photo-preview', src: photoData, alt: 'New bottle photo' }));
      } catch (e) { err.textContent = e.message; }
    });
    const removeBtn = med && med.photoUrl ? h('button', { class: 'btn btn-small btn-outline', type: 'button', onclick: () => { removePhoto = true; photoData = undefined; photoShow.replaceChildren(h('em', {}, 'Photo will be removed.')); } }, 'Remove photo') : null;

    const form = h('form', { method: 'dialog', novalidate: true, onsubmit: async (e) => {
      e.preventDefault();
      err.textContent = '';
      const schedule = Object.keys(defaults).filter((s) => $(`slot-${s}`).checked).map((s) => ({ slot: s, time: $(`time-${s}`).value }));
      const body = {
        name: $('f-name').value, dosage: $('f-dosage').value, purpose: $('f-purpose').value, note: $('f-note').value,
        food: form.querySelector('input[name=food]:checked').value, color: colorSel.value, shape: shapeSel.value,
        stock: $('f-stock').value, schedule, photo: photoData, removePhoto,
      };
      try {
        if (editing) await api.put(`/api/meds/${med.id}`, body); else await api.post(`/api/patients/${pid}/meds`, body);
        dlg.close();
        PP.toast(editing ? 'Changes saved.' : `${body.name} added.`);
        refresh();
      } catch (ex) { err.textContent = ex.message; }
    } },
      h('h2', { id: 'med-dialog-title' }, editing ? `Edit ${med.name}` : 'Add a medicine'),
      text('f-name', 'Medicine name', v.name, { autocomplete: 'off' }),
      text('f-dosage', 'Dosage (for example 5 mg)', v.dosage),
      text('f-purpose', 'What it is for (shown to the senior)', v.purpose),
      h('fieldset', {}, h('legend', {}, 'When to take it'), slotRows),
      h('fieldset', {}, h('legend', {}, 'Food'), foodRows),
      text('f-note', 'Extra instruction (for example: Take with water)', v.note),
      h('div', { class: 'field' }, h('label', { for: 'f-stock' }, 'Doses left in the bottle'), h('input', { type: 'number', id: 'f-stock', min: '0', max: '999', value: String(v.stock), inputmode: 'numeric' })),
      h('div', { class: 'row', style: 'flex-wrap:wrap;margin-bottom:0.9rem' },
        h('div', { class: 'field', style: 'flex:1;margin:0' }, h('label', { for: 'f-color' }, 'Pill colour'), colorSel),
        h('div', { class: 'field', style: 'flex:1;margin:0' }, h('label', { for: 'f-shape' }, 'Pill shape'), shapeSel),
        preview),
      h('div', { class: 'field' }, h('label', { for: 'f-photo' }, 'Photo of the pill bottle (optional)'), photoInput, photoShow, removeBtn),
      err,
      h('div', { class: 'row', style: 'flex-wrap:wrap' },
        h('button', { class: 'btn btn-primary', type: 'submit' }, editing ? 'Save changes' : 'Add medicine'),
        h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Cancel')));

    dlg.replaceChildren(form);
    dlg.showModal();
  }

  // ---- alerts feed ------------------------------------------------------------
  function renderAlerts() {
    const list = data.alerts.alerts;
    $('panel-alerts').replaceChildren(
      h('h2', {}, 'Everything that happened'),
      list.length
        ? h('ul', { class: 'timeline' }, list.map((a) => {
          const t = alertText(a);
          return h('li', { class: `tl ${t.tone}` },
            h('span', { class: 'icon', 'aria-hidden': 'true' }, t.icon),
            h('div', {}, h('div', { class: 'title' }, t.title), h('div', { class: 'sub' }, `${t.detail} (${PP.ago(a.at, PP.nowMs())})`)),
            !a.ack && a.severity !== 'ok'
              ? h('button', { class: 'btn btn-small', type: 'button', onclick: async () => { await api.post(`/api/alerts/${a.id}/ack`); refresh(); } }, 'Got it')
              : null);
        }))
        : h('p', {}, 'Nothing yet.'));
  }

  // ---- demo controls ----------------------------------------------------------
  function renderDemoSelect() {
    const sel = $('demo-dose');
    const keep = sel.value;
    const open = data.today.doses.filter((d) => d.status !== 'missed');
    sel.replaceChildren(h('option', { value: '' }, 'Next medicine on the list'),
      ...open.map((d) => h('option', { value: d.id }, `${PP.fmtTime(d.scheduledAt)} ${d.med.name}${d.status === 'taken' ? ' (already taken)' : ''}`)));
    if ([...sel.options].some((o) => o.value === keep)) sel.value = keep;
  }

  $('demo-trigger').addEventListener('click', async () => {
    try {
      const dose = await api.post('/api/demo/trigger', { patientId: pid, doseId: $('demo-dose').value || undefined });
      PP.toast(`Reminder sent: ${dose.med.name}. Watch the senior screen.`);
      refresh();
    } catch (e) { PP.toast(e.message); }
  });
  $('demo-skip').addEventListener('click', async () => {
    try {
      const r = await api.post('/api/demo/advance', { minutes: 31 });
      PP.toast(r.escalated ? 'Skipped 31 minutes. Missed-dose alert sent.' : 'Skipped 31 minutes. Nothing was overdue.');
      refresh();
    } catch (e) { PP.toast(e.message); }
  });
  $('demo-reset').addEventListener('click', async () => {
    if (!confirm('Reset all demo data and the demo clock?')) return;
    try { await api.post('/api/demo/reset'); seenAlerts = null; PP.toast('Demo data reset.'); refresh(); } catch (e) { PP.toast(e.message); }
  });

  // ---- start ------------------------------------------------------------------
  async function start() {
    patients = await api.get('/api/patients');
    const sel = $('patient-select');
    sel.replaceChildren(...patients.map((p) => h('option', { value: p.id, selected: p.id === pid }, p.name)));
    sel.addEventListener('change', () => {
      pid = sel.value;
      localStorage.setItem('pp.patient', pid);
      history.replaceState(null, '', `?p=${pid}`);
      seenAlerts = null;
      refresh();
    });
    PP.liveUpdates(refresh, (ok) => { const el = $('live'); el.classList.toggle('off', !ok); el.lastChild.textContent = ok ? 'Live' : 'Reconnecting'; });
    PP.backgroundTicker(5000, refresh);    // fallback poll, also keeps "x min ago" fresh
    refresh();
  }
  start().catch(() => PP.toast('Could not reach the server.'));
})();
