// Shared helpers for the senior and caregiver screens.
// Exposed as one global, PP, to keep the pages free of a build step.

const PP = (() => {
  // ---- server clock -----------------------------------------------------------
  // The server can run on a skewed "demo clock", so we always show the server's time.
  let skew = 0;
  const syncClock = (serverNow) => { skew = serverNow - Date.now(); };
  const nowMs = () => Date.now() + skew;

  // ---- api --------------------------------------------------------------------
  async function request(method, url, body) {
    const res = await fetch(url, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch { /* empty body */ }
    if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`);
    return data;
  }
  const api = {
    get: (u) => request('GET', u),
    post: (u, b) => request('POST', u, b || {}),
    put: (u, b) => request('PUT', u, b),
    del: (u) => request('DELETE', u),
  };

  // ---- tiny DOM builder (text goes in as text, so names can never inject markup) --
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style') el.style.cssText = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(kid));
    }
    return el;
  }

  // replaceChildren() would print the word "null" for a null child, so skip empties.
  function fill(el, ...kids) {
    el.replaceChildren(...kids.flat().filter((k) => k != null && k !== false));
    return el;
  }

  // ---- formatting -------------------------------------------------------------
  const fmtTime = (ms) => new Date(ms).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
  const fmtDate = (ms) => new Date(ms).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });
  const SLOT_LABEL = { morning: 'Morning', afternoon: 'Afternoon', night: 'Night' };
  const FOOD_TEXT = { with: 'Take with food', without: 'Take on an empty stomach', any: 'With or without food' };

  // What to tell the senior about how to take a medicine (never repeats itself).
  function instructions(m) {
    const lines = [];
    if (m.note) lines.push(m.note);
    if (m.food !== 'any') lines.push(FOOD_TEXT[m.food]);
    return lines.length ? lines : ['Take as directed'];
  }

  function ago(ms, now) {
    const mins = Math.max(0, Math.round((now - ms) / 60000));
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins} min ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs} hr${hrs > 1 ? 's' : ''} ago`;
    const days = Math.floor(hrs / 24);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }

  // ---- pill pictures (colour is never the only clue: the shape and the name are shown too) --
  const PILL_COLORS = {
    white: '#f4f4f4', pink: '#f27aa3', yellow: '#ffd21f', blue: '#4a9df0',
    orange: '#ff9a2e', green: '#5cc26b', red: '#e8504f',
  };
  const PILL_NAMES = { white: 'White', pink: 'Pink', yellow: 'Yellow', blue: 'Blue', orange: 'Orange', green: 'Green', red: 'Red' };

  function pillSvg(color, shape, px = 72) {
    const c = PILL_COLORS[color] || PILL_COLORS.white;
    const half = color === 'white' ? '#d9d9d9' : '#ffffff';
    let body;
    if (shape === 'capsule') {
      body = `<g transform="rotate(-35 50 50)">
        <path d="M30 32h20v36H30a18 18 0 0 1 0-36z" fill="${c}" stroke="#111" stroke-width="5" stroke-linejoin="round"/>
        <path d="M50 32h20a18 18 0 0 1 0 36H50z" fill="${half}" stroke="#111" stroke-width="5" stroke-linejoin="round"/></g>`;
    } else if (shape === 'oval') {
      body = `<g transform="rotate(-30 50 50)"><ellipse cx="50" cy="50" rx="42" ry="26" fill="${c}" stroke="#111" stroke-width="5"/>
        <line x1="50" y1="26" x2="50" y2="74" stroke="#111" stroke-opacity=".45" stroke-width="4"/></g>`;
    } else {
      body = `<circle cx="50" cy="50" r="38" fill="${c}" stroke="#111" stroke-width="5"/>
        <line x1="22" y1="50" x2="78" y2="50" stroke="#111" stroke-opacity=".45" stroke-width="4"/>`;
    }
    const wrap = document.createElement('span');
    wrap.className = 'pill-icon';
    wrap.style.cssText = `width:${px}px;height:${px}px`;
    wrap.innerHTML = `<svg viewBox="0 0 100 100" width="${px}" height="${px}" role="img" aria-label="${PILL_NAMES[color] || 'White'} ${shape} pill">${body}</svg>`;
    return wrap;
  }
  const pillWords = (m) => `${PILL_NAMES[m.color] || 'White'} ${m.shape === 'round' ? 'round' : m.shape} ${m.shape === 'capsule' ? 'capsule' : 'tablet'}`;

  // ---- sound ------------------------------------------------------------------
  let audioCtx = null;
  function audio() {
    if (!audioCtx) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (Ctx) audioCtx = new Ctx();
    }
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    return audioCtx;
  }
  // Browsers only allow sound after a tap, so the first tap anywhere unlocks it.
  const unlockOnce = () => { audio(); window.removeEventListener('pointerdown', unlockOnce); window.removeEventListener('keydown', unlockOnce); };
  window.addEventListener('pointerdown', unlockOnce);
  window.addEventListener('keydown', unlockOnce);

  function playNotes(notes, { type = 'sine', gap = 0.28, peak = 0.35, length = 0.9 } = {}) {
    const ctx = audio();
    if (!ctx || ctx.state !== 'running') return false;
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const t = ctx.currentTime + i * gap;
      osc.type = type;
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(peak, t + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + length);
      osc.connect(gain).connect(ctx.destination);
      osc.start(t);
      osc.stop(t + length + 0.1);
    });
    return true;
  }
  const chime = () => playNotes([659.25, 783.99, 1046.5]);                          // friendly, for the senior
  const alarm = () => playNotes([880, 660, 880, 660], { type: 'square', gap: 0.22, peak: 0.12, length: 0.2 }); // urgent, for the caregiver
  const audioReady = () => !!audioCtx && audioCtx.state === 'running';

  // ---- speech -----------------------------------------------------------------
  function speak(text, lang) {
    if (!('speechSynthesis' in window) || !text) return false;
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang;
    u.rate = 0.85;
    const voices = speechSynthesis.getVoices();
    const want = lang.toLowerCase();
    const voice = voices.find((v) => v.lang.replace('_', '-').toLowerCase() === want)
      || voices.find((v) => v.lang.toLowerCase().startsWith(want.slice(0, 2)));
    if (voice) u.voice = voice;
    speechSynthesis.speak(u);
    return true;
  }
  const stopSpeaking = () => { if ('speechSynthesis' in window) speechSynthesis.cancel(); };

  // ---- desktop notifications --------------------------------------------------
  const canNotify = () => 'Notification' in window;
  async function askNotifyPermission() {
    if (!canNotify() || Notification.permission !== 'default') return;
    try { await Notification.requestPermission(); } catch { /* old Safari */ }
  }
  function notify(title, body, tag) {
    if (!canNotify() || Notification.permission !== 'granted') return;
    try {
      const n = new Notification(title, { body, tag, requireInteraction: true });
      n.onclick = () => { window.focus(); n.close(); };
    } catch { /* some mobile browsers only allow service-worker notifications */ }
  }

  // ---- background timer -------------------------------------------------------
  // A Web Worker's timers are not slowed down when the tab is hidden, unlike setInterval
  // on the page, so the worker is what keeps reminders on time in a background tab.
  function backgroundTicker(everyMs, fn) {
    try {
      const src = `setInterval(() => postMessage(1), ${everyMs});`;
      const worker = new Worker(URL.createObjectURL(new Blob([src], { type: 'text/javascript' })));
      worker.onmessage = fn;
      return () => worker.terminate();
    } catch {
      const id = setInterval(fn, everyMs);   // fallback if workers are blocked
      return () => clearInterval(id);
    }
  }

  // ---- live updates -----------------------------------------------------------
  function liveUpdates(onUpdate, onStatus) {
    let source;
    const connect = () => {
      source = new EventSource('/api/events');
      source.onopen = () => onStatus && onStatus(true);
      source.onmessage = () => onUpdate();
      source.onerror = () => onStatus && onStatus(false);   // EventSource retries by itself
    };
    connect();
  }

  // ---- preferences (theme, text size) ----------------------------------------
  function applyPrefs(scope, defaultSize) {
    const theme = localStorage.getItem('pp.theme') || 'light';
    const size = localStorage.getItem(`pp.size.${scope}`) ?? String(defaultSize);
    document.documentElement.dataset.theme = theme;
    document.documentElement.dataset.size = size;
  }
  function prefsBar(scope, defaultSize) {
    const bump = (d) => () => {
      const cur = Number(document.documentElement.dataset.size);
      const next = Math.min(2, Math.max(0, cur + d));
      localStorage.setItem(`pp.size.${scope}`, String(next));
      applyPrefs(scope, defaultSize);
    };
    const themeBtn = h('button', { class: 'btn btn-outline', type: 'button', 'aria-label': 'Switch between light and dark display' },
      document.documentElement.dataset.theme === 'dark' ? 'Light display' : 'Dark display');
    themeBtn.addEventListener('click', () => {
      const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
      localStorage.setItem('pp.theme', next);
      applyPrefs(scope, defaultSize);
      themeBtn.textContent = next === 'dark' ? 'Light display' : 'Dark display';
    });
    return h('div', { class: 'prefs', role: 'group', 'aria-label': 'Display settings' },
      h('button', { class: 'btn btn-outline', type: 'button', 'aria-label': 'Smaller text', onclick: bump(-1) }, 'A−'),
      h('button', { class: 'btn btn-outline', type: 'button', 'aria-label': 'Larger text', onclick: bump(1) }, 'A+'),
      themeBtn);
  }

  function toast(message, ms = 3500) {
    const t = h('div', { class: 'toast', role: 'status' }, message);
    document.body.append(t);
    setTimeout(() => t.remove(), ms);
  }

  return {
    api, h, fill, instructions, syncClock, nowMs, fmtTime, fmtDate, ago, SLOT_LABEL, FOOD_TEXT,
    PILL_COLORS, PILL_NAMES, pillSvg, pillWords,
    chime, alarm, audioReady, speak, stopSpeaking,
    canNotify, askNotifyPermission, notify, backgroundTicker, liveUpdates,
    applyPrefs, prefsBar, toast,
  };
})();
