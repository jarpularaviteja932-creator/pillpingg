const SLOTS = ['morning', 'afternoon', 'night'];
const FOODS = ['with', 'without', 'any'];
const COLORS = ['white', 'pink', 'yellow', 'blue', 'orange', 'green', 'red'];
const SHAPES = ['round', 'oval', 'capsule'];
const DEFAULT_TIMES = { morning: '09:00', afternoon: '14:00', night: '21:00' };
const MAX_PHOTO_CHARS = 400 * 1024;

const clean = (s, max) => String(s ?? '').replace(/\s+/g, ' ').trim().slice(0, max);

// Turns whatever the form posted into a medication record, or says what is wrong.
function parseMedication(body) {
  if (!body || typeof body !== 'object') return { error: 'Missing medicine details.' };

  const name = clean(body.name, 60);
  if (!name) return { error: 'Please enter the medicine name.' };

  const dosage = clean(body.dosage, 40);
  if (!dosage) return { error: 'Please enter the dosage, for example "5 mg".' };

  const food = FOODS.includes(body.food) ? body.food : 'any';
  const color = COLORS.includes(body.color) ? body.color : 'white';
  const shape = SHAPES.includes(body.shape) ? body.shape : 'round';

  const rawSchedule = Array.isArray(body.schedule) ? body.schedule : [];
  const seen = new Set();
  const schedule = [];
  for (const entry of rawSchedule) {
    if (!entry || !SLOTS.includes(entry.slot) || seen.has(entry.slot)) continue;
    const time = /^([01]\d|2[0-3]):[0-5]\d$/.test(entry.time) ? entry.time : DEFAULT_TIMES[entry.slot];
    seen.add(entry.slot);
    schedule.push({ slot: entry.slot, time });
  }
  if (!schedule.length) return { error: 'Pick at least one time of day.' };
  schedule.sort((a, b) => a.time.localeCompare(b.time));

  const stock = Number.parseInt(body.stock, 10);
  if (!Number.isInteger(stock) || stock < 0 || stock > 999) {
    return { error: 'Doses left must be a number between 0 and 999.' };
  }

  let photo;
  if (typeof body.photo === 'string' && body.photo) {
    if (!/^data:image\/(jpeg|png|webp);base64,/.test(body.photo)) return { error: 'Photo must be a JPEG, PNG or WebP image.' };
    if (body.photo.length > MAX_PHOTO_CHARS) return { error: 'That photo is too large. Try a smaller one.' };
    photo = body.photo;
  }

  return {
    value: {
      name, dosage, food, color, shape, schedule, stock,
      purpose: clean(body.purpose, 60),
      note: clean(body.note, 80),
      photo,                              // undefined = leave unchanged
      removePhoto: body.removePhoto === true,
    },
  };
}

module.exports = { parseMedication, SLOTS, FOODS, COLORS, SHAPES, DEFAULT_TIMES };
