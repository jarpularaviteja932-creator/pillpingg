// All the medication logic lives here as plain functions over the db object,
// so the server stays thin and the tests don't need a running server.

const crypto = require('crypto');
const { dateKey, at, shiftKey } = require('./dates');

const GRACE_MIN = 30;       // minutes before a silent dose counts as missed
const SNOOZE_MIN = 15;
const REFILL_BELOW = 5;     // warn caregivers when fewer than this many doses remain
const GRACE_MS = GRACE_MIN * 60000;

const newId = () => crypto.randomUUID().slice(0, 8);

function doseId(medId, date, slot) {
  return `${medId}_${date}_${slot}`;
}

function makeDose(med, entry, date) {
  return {
    id: doseId(med.id, date, entry.slot),
    patientId: med.patientId,
    medId: med.id,
    date,
    slot: entry.slot,
    scheduledAt: at(date, entry.time),
    status: 'pending',        // pending | taken | missed
    takenAt: null,
    onTime: null,
    selfReported: false,      // true when the senior used "I Already Took It"
    snoozedUntil: null,
    snoozeCount: 0,
  };
}

// Creates the day's dose rows for every active medicine. Safe to call repeatedly.
function ensureDoses(db, date) {
  let created = 0;
  const have = new Set(db.doses.filter((d) => d.date === date).map((d) => d.id));
  for (const med of db.meds) {
    if (!med.active) continue;
    for (const entry of med.schedule) {
      if (have.has(doseId(med.id, date, entry.slot))) continue;
      db.doses.push(makeDose(med, entry, date));
      created++;
    }
  }
  return created;
}

function addAlert(db, fields) {
  const alert = {
    id: newId(),
    at: fields.at,
    ack: false,
    resolved: false,
    ...fields,
  };
  db.alerts.push(alert);
  return alert;
}

function medOf(db, id) {
  return db.meds.find((m) => m.id === id);
}

// The moment a pending dose should (re)appear on the senior's screen.
function dueAt(dose) {
  return dose.snoozedUntil && dose.snoozedUntil > dose.scheduledAt ? dose.snoozedUntil : dose.scheduledAt;
}

function stateOf(dose, now) {
  if (dose.status === 'taken') return dose.onTime ? 'taken' : 'late';
  if (dose.status === 'missed') return 'missed';
  if (now < dose.scheduledAt) return 'upcoming';
  return dueAt(dose) <= now ? 'due' : 'snoozed';
}

// Runs every few seconds. Opens today's doses and escalates anything that has gone
// unconfirmed for GRACE_MIN. Returns the new alerts so the server can "send" them.
function tick(db, now) {
  const fresh = [];
  ensureDoses(db, dateKey(now));

  for (const dose of db.doses) {
    if (dose.status !== 'pending') continue;
    if (now < dose.scheduledAt + GRACE_MS) continue;
    const med = medOf(db, dose.medId);
    if (!med) continue;

    dose.status = 'missed';
    fresh.push(addAlert(db, {
      type: 'missed',
      severity: 'urgent',
      patientId: dose.patientId,
      doseId: dose.id,
      medId: med.id,
      medName: med.name,
      dosage: med.dosage,
      slot: dose.slot,
      scheduledAt: dose.scheduledAt,
      at: now,
    }));
  }
  return fresh;
}

// Confirms a dose. Works for pending doses and for ones already flagged as missed
// (the senior took the pill but forgot to tap), which is what "retroactive" means here.
function takeDose(db, id, now, { selfReported = false } = {}) {
  const dose = db.doses.find((d) => d.id === id);
  if (!dose) return { error: 'Dose not found.', code: 404 };
  const med = medOf(db, dose.medId);
  if (!med) return { error: 'Medicine not found.', code: 404 };
  if (dose.status === 'taken') return { dose, med, alerts: [], duplicate: true };

  const wasMissed = dose.status === 'missed';
  dose.status = 'taken';
  dose.takenAt = now;
  dose.onTime = !wasMissed && now - dose.scheduledAt <= GRACE_MS;
  dose.selfReported = selfReported;
  dose.snoozedUntil = null;

  // the earlier red alert no longer needs anyone's attention
  for (const a of db.alerts) {
    if (a.doseId === dose.id && a.type === 'missed') { a.resolved = true; a.ack = true; }
  }

  const alerts = [];
  alerts.push(addAlert(db, {
    type: wasMissed ? 'late' : 'taken',
    severity: wasMissed ? 'warn' : 'ok',
    patientId: dose.patientId,
    doseId: dose.id,
    medId: med.id,
    medName: med.name,
    dosage: med.dosage,
    slot: dose.slot,
    scheduledAt: dose.scheduledAt,
    selfReported,
    at: now,
  }));

  med.stock = Math.max(0, med.stock - 1);
  if (med.stock < REFILL_BELOW && !med.refillAlerted) {
    med.refillAlerted = true;
    alerts.push(addAlert(db, {
      type: 'refill',
      severity: 'warn',
      patientId: dose.patientId,
      medId: med.id,
      medName: med.name,
      dosage: med.dosage,
      stock: med.stock,
      at: now,
    }));
  }
  return { dose, med, alerts };
}

// Snoozing pushes the reminder back but does not move the grace window:
// the caregiver is still told 30 minutes after the *original* time.
function snoozeDose(db, id, now) {
  const dose = db.doses.find((d) => d.id === id);
  if (!dose) return { error: 'Dose not found.', code: 404 };
  if (dose.status !== 'pending') return { error: 'That dose is already finished.', code: 409 };
  dose.snoozedUntil = now + SNOOZE_MIN * 60000;
  dose.snoozeCount += 1;
  return { dose };
}

function refillMed(db, medId, count, now) {
  const med = medOf(db, medId);
  if (!med) return { error: 'Medicine not found.', code: 404 };
  const n = Number.parseInt(count, 10);
  if (!Number.isInteger(n) || n < 1 || n > 999) return { error: 'Enter how many doses were added (1 to 999).', code: 400 };
  med.stock += n;
  if (med.stock >= REFILL_BELOW) med.refillAlerted = false;
  for (const a of db.alerts) {
    if (a.type === 'refill' && a.medId === med.id) { a.resolved = true; a.ack = true; }
  }
  return { med };
}

// ---- adherence --------------------------------------------------------------

function summarize(doses, now) {
  // only count doses whose outcome is known: taken, missed, or past their grace window
  const counted = doses.filter((d) => d.status !== 'pending' || now >= d.scheduledAt + GRACE_MS);
  const total = counted.length;
  const taken = counted.filter((d) => d.status === 'taken').length;
  const onTime = counted.filter((d) => d.status === 'taken' && d.onTime).length;
  const pct = (n) => (total ? Math.round((n / total) * 100) : null);
  return { total, taken, onTime, takenPct: pct(taken), onTimePct: pct(onTime) };
}

function adherence(db, patientId, now, days = 14) {
  const today = dateKey(now);
  const mine = db.doses.filter((d) => d.patientId === patientId);
  const rows = [];

  for (let i = days - 1; i >= 0; i--) {
    const date = shiftKey(today, -i);
    const doses = mine
      .filter((d) => d.date === date)
      .sort((a, b) => a.scheduledAt - b.scheduledAt)
      .map((d) => {
        const med = medOf(db, d.medId);
        return {
          id: d.id, medName: med ? med.name : 'Removed medicine', slot: d.slot,
          scheduledAt: d.scheduledAt, takenAt: d.takenAt, state: stateOf(d, now),
        };
      });

    let state = 'none';
    if (doses.length) {
      if (doses.some((d) => d.state === 'missed')) state = 'red';
      else if (doses.some((d) => ['upcoming', 'due', 'snoozed'].includes(d.state))) state = 'pending';
      else state = 'green';
    }
    rows.push({ date, state, doses });
  }

  const inRange = (from, to) => mine.filter((d) => d.date >= shiftKey(today, from) && d.date <= shiftKey(today, to));
  return {
    now,
    last7: summarize(inRange(-6, 0), now),
    prev7: summarize(inRange(-13, -7), now),
    days: rows,
  };
}

module.exports = {
  GRACE_MIN, SNOOZE_MIN, REFILL_BELOW,
  newId, doseId, makeDose, ensureDoses, addAlert, medOf, dueAt, stateOf,
  tick, takeDose, snoozeDose, refillMed, adherence, summarize,
};
