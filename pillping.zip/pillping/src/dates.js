// Small local-time helpers. Everything is keyed by local calendar date (YYYY-MM-DD),
// because "morning dose" means morning where the patient lives.

const pad = (n) => String(n).padStart(2, '0');

function dateKey(ms) {
  const d = new Date(ms);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// "2026-11-20" + "10:00" -> epoch ms in local time
function at(key, hhmm) {
  const [y, m, d] = key.split('-').map(Number);
  const [h, mi] = hhmm.split(':').map(Number);
  return new Date(y, m - 1, d, h, mi, 0, 0).getTime();
}

function shiftKey(key, days) {
  const [y, m, d] = key.split('-').map(Number);
  // noon avoids DST edge cases when adding days
  return dateKey(new Date(y, m - 1, d + days, 12).getTime());
}

module.exports = { dateKey, at, shiftKey };
