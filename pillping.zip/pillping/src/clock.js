// The server's idea of "now". It is just Date.now() plus an offset, and the offset
// only changes from the demo controls ("skip ahead 31 minutes"). That lets you show
// the 30-minute missed-dose escalation in a live demo without waiting half an hour.

let offsetMs = 0;

module.exports = {
  now: () => Date.now() + offsetMs,
  advance: (minutes) => { offsetMs += minutes * 60000; },
  reset: () => { offsetMs = 0; },
  offset: () => offsetMs,
};
