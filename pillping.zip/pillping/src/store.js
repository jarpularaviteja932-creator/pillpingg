// Tiny JSON-file "database". The whole dataset is a few hundred rows, so writing the
// file on every change is fine, and it keeps the project free of native dependencies.

const fs = require('fs');
const path = require('path');
const { buildSeed } = require('./seed');

class Store {
  constructor(file) {
    this.file = file;
    this.db = null;
  }

  load(now) {
    try {
      this.db = JSON.parse(fs.readFileSync(this.file, 'utf8'));
      if (!this.db.patients || !this.db.meds || !this.db.doses || !this.db.alerts) throw new Error('shape');
    } catch (err) {
      if (err.code !== 'ENOENT') {
        // unreadable file: keep a copy instead of silently throwing it away
        try { fs.renameSync(this.file, `${this.file}.broken-${Date.now()}`); } catch { /* nothing to keep */ }
        console.warn('Data file was unreadable, starting from sample data.');
      }
      this.reseed(now);
    }
    return this.db;
  }

  reseed(now) {
    this.db = buildSeed(now);
    this.save();
  }

  save() {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const tmp = `${this.file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.db));
    fs.renameSync(tmp, this.file);   // rename is atomic, so a crash can't leave half a file
  }
}

module.exports = { Store };
