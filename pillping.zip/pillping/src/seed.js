// Sample data: two elderly patients, four chronic medications each, and 14 days of
// adherence history. History is generated relative to "today" so the calendar always
// looks current, using a seeded random generator so every reset gives the same story.

const { dateKey, shiftKey } = require('./dates');
const { makeDose, ensureDoses, addAlert, GRACE_MIN, REFILL_BELOW } = require('./doses');

function rng(seed) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const patients = [
  {
    id: 'p1',
    name: 'Ramesh Rao',
    callName: 'Dad',
    age: 68,
    conditions: ['Hypertension', 'Type 2 diabetes', 'Heart disease'],
    voiceLang: 'te-IN',
    caregiver: { name: 'Anil', relation: 'Son', phone: '+919876500001' },
    emergencyNumber: '108',
    // how often the sample history shows an on-time dose / a late one (rest are missed)
    history: { onTime: 0.92, late: 0.04, seed: 11 },
  },
  {
    id: 'p2',
    name: 'Savitri Devi',
    callName: 'Mom',
    age: 72,
    conditions: ['Hypertension', 'Type 2 diabetes', 'Atrial fibrillation'],
    voiceLang: 'hi-IN',
    caregiver: { name: 'Priya', relation: 'Daughter', phone: '+919876500002' },
    emergencyNumber: '108',
    history: { onTime: 0.8, late: 0.08, seed: 29 },
  },
];

const med = (id, patientId, name, dosage, purpose, schedule, food, note, color, shape, stock) => ({
  id, patientId, name, dosage, purpose, schedule, food, note, color, shape, stock,
  refillAlerted: stock < REFILL_BELOW, active: true, photo: null, photoV: 0,
});

const meds = [
  med('p1-metformin', 'p1', 'Metformin', '500 mg', 'Blood sugar',
    [{ slot: 'morning', time: '08:30' }, { slot: 'night', time: '20:30' }], 'with', 'Take with water', 'white', 'round', 38),
  med('p1-amlodipine', 'p1', 'Amlodipine', '5 mg', 'Blood pressure pill',
    [{ slot: 'morning', time: '10:00' }], 'any', 'Take with water', 'pink', 'round', 21),
  med('p1-aspirin', 'p1', 'Aspirin', '75 mg', 'Heart protection',
    [{ slot: 'afternoon', time: '14:00' }], 'with', 'Swallow whole, do not crush', 'orange', 'round', 5),
  med('p1-atorvastatin', 'p1', 'Atorvastatin', '10 mg', 'Cholesterol',
    [{ slot: 'night', time: '21:00' }], 'any', 'Take with water', 'yellow', 'oval', 27),

  med('p2-telmisartan', 'p2', 'Telmisartan', '40 mg', 'Blood pressure pill',
    [{ slot: 'morning', time: '09:00' }], 'any', 'Take with water', 'blue', 'oval', 30),
  med('p2-glimepiride', 'p2', 'Glimepiride', '1 mg', 'Blood sugar',
    [{ slot: 'morning', time: '07:30' }], 'without', 'Take with water', 'green', 'round', 24),
  med('p2-metoprolol', 'p2', 'Metoprolol', '25 mg', 'Heart rate',
    [{ slot: 'morning', time: '09:00' }, { slot: 'night', time: '21:00' }], 'with', 'Take with water', 'white', 'capsule', 4),
  med('p2-clopidogrel', 'p2', 'Clopidogrel', '75 mg', 'Prevents blood clots',
    [{ slot: 'afternoon', time: '14:00' }], 'any', 'Take with water', 'red', 'capsule', 19),
];

function buildSeed(now) {
  const today = dateKey(now);
  const db = {
    patients: patients.map(({ history, ...p }) => p),
    meds: meds.map((m) => JSON.parse(JSON.stringify(m))),
    doses: [],
    alerts: [],
  };

  // history: the 14 days before today
  for (const patient of patients) {
    const rand = rng(patient.history.seed);
    for (let back = 14; back >= 1; back--) {
      const date = shiftKey(today, -back);
      for (const m of db.meds.filter((x) => x.patientId === patient.id)) {
        for (const entry of m.schedule) {
          const dose = makeDose(m, entry, date);
          const roll = rand();
          if (roll < patient.history.onTime) {
            dose.status = 'taken';
            dose.takenAt = dose.scheduledAt + Math.round(rand() * 12) * 60000;
            dose.onTime = true;
          } else if (roll < patient.history.onTime + patient.history.late) {
            dose.status = 'taken';
            dose.takenAt = dose.scheduledAt + (35 + Math.round(rand() * 80)) * 60000;
            dose.onTime = false;
            dose.selfReported = true;
          } else {
            dose.status = 'missed';
          }
          db.doses.push(dose);

          // only the last few days leave a trace in the alert feed
          if (back <= 4 && dose.status === 'missed') {
            addAlert(db, { type: 'missed', severity: 'urgent', patientId: patient.id, doseId: dose.id,
              medId: m.id, medName: m.name, dosage: m.dosage, slot: entry.slot, scheduledAt: dose.scheduledAt,
              at: dose.scheduledAt + GRACE_MIN * 60000, ack: true });
          } else if (back <= 4 && dose.status === 'taken' && !dose.onTime) {
            addAlert(db, { type: 'late', severity: 'warn', patientId: patient.id, doseId: dose.id,
              medId: m.id, medName: m.name, dosage: m.dosage, slot: entry.slot, scheduledAt: dose.scheduledAt,
              selfReported: true, at: dose.takenAt, ack: true });
          }
        }
      }
    }
  }

  // today: anything whose window has already closed was taken on time
  ensureDoses(db, today);
  const rand = rng(7);
  for (const dose of db.doses.filter((d) => d.date === today)) {
    if (now >= dose.scheduledAt + GRACE_MIN * 60000) {
      const m = db.meds.find((x) => x.id === dose.medId);
      dose.status = 'taken';
      dose.takenAt = dose.scheduledAt + (1 + Math.round(rand() * 9)) * 60000;
      dose.onTime = true;
      addAlert(db, { type: 'taken', severity: 'ok', patientId: dose.patientId, doseId: dose.id,
        medId: m.id, medName: m.name, dosage: m.dosage, slot: dose.slot, scheduledAt: dose.scheduledAt,
        at: dose.takenAt, ack: true });
    }
  }

  // a refill warning so the caregiver feed is not empty on first open
  for (const m of db.meds.filter((x) => x.stock < REFILL_BELOW)) {
    addAlert(db, { type: 'refill', severity: 'warn', patientId: m.patientId, medId: m.id,
      medName: m.name, dosage: m.dosage, stock: m.stock, at: now - 2 * 3600000 });
  }

  db.alerts.sort((a, b) => a.at - b.at);
  return db;
}

module.exports = { buildSeed };
