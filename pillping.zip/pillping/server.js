// PillPing server: static files + a small REST API + server-sent events.
// Plain Node, no packages to install.

const http = require('http');
const fs = require('fs');
const path = require('path');

const clock = require('./src/clock');
const { dateKey } = require('./src/dates');
const { Store } = require('./src/store');
const { parseMedication } = require('./src/validate');
const D = require('./src/doses');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_FILE = process.env.PILLPING_DATA || path.join(__dirname, 'data', 'db.json');

const store = new Store(DATA_FILE);
store.load(clock.now());
const db = () => store.db;

// ---- live updates -------------------------------------------------------------

const listeners = new Set();

function broadcast() {
  for (const res of listeners) res.write('data: {"type":"update"}\n\n');
}

function commit() {
  store.save();
  broadcast();
}

// Pretend to be the SMS/push gateway. In a real product this is where Twilio or FCM goes.
function dispatch(alerts) {
  for (const a of alerts) {
    if (a.severity !== 'urgent') continue;
    const patient = db().patients.find((p) => p.id === a.patientId);
    if (!patient) continue;
    const what = a.type === 'sos' ? 'pressed the SOS button' : `has not confirmed ${a.medName} ${a.dosage}`;
    console.log(`[simulated SMS to ${patient.caregiver.name} ${patient.caregiver.phone}] ${patient.name} ${what}.`);
  }
}

// Every 5 seconds: open today's doses and escalate anything unconfirmed past the grace window.
setInterval(() => {
  const fresh = D.tick(db(), clock.now());
  if (fresh.length) { dispatch(fresh); commit(); }
}, 5000);

// ---- helpers ------------------------------------------------------------------

function json(res, code, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > 1024 * 1024) { reject(Object.assign(new Error('Request too large.'), { code: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(Object.assign(new Error('That request was not valid JSON.'), { code: 400 })); }
    });
    req.on('error', reject);
  });
}

const publicMed = (m) => ({
  id: m.id, patientId: m.patientId, name: m.name, dosage: m.dosage, purpose: m.purpose,
  schedule: m.schedule, food: m.food, note: m.note, color: m.color, shape: m.shape,
  stock: m.stock, lowStock: m.stock < D.REFILL_BELOW,
  photoUrl: m.photo ? `/api/meds/${m.id}/photo?v=${m.photoV}` : null,
});

const getPatient = (id) => db().patients.find((p) => p.id === id);

function viewDose(dose, now) {
  const med = D.medOf(db(), dose.medId);
  return {
    id: dose.id, date: dose.date, slot: dose.slot, scheduledAt: dose.scheduledAt,
    status: dose.status, state: D.stateOf(dose, now), takenAt: dose.takenAt, onTime: dose.onTime,
    selfReported: dose.selfReported, snoozedUntil: dose.snoozedUntil, dueAt: D.dueAt(dose),
    med: med ? publicMed(med) : null,
  };
}

// ---- routes -------------------------------------------------------------------

const routes = [];
const route = (method, pattern, handler) => {
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$');
  routes.push({ method, re, handler });
};
// Handlers return plain data (sent as 200) or one of these when they need a different status.
const REPLY = Symbol('reply');
const reply = (code, payload) => ({ [REPLY]: true, code, payload });
const fail = (code, error) => reply(code, { error });

route('GET', '/api/patients', () => db().patients);

route('GET', '/api/patients/:id/today', ({ params }) => {
  const patient = getPatient(params.id);
  if (!patient) return fail(404, 'Patient not found.');
  const now = clock.now();
  const fresh = D.tick(db(), now);
  if (fresh.length) { dispatch(fresh); commit(); }

  const today = dateKey(now);
  const doses = db().doses
    .filter((d) => d.patientId === patient.id && d.date === today && D.medOf(db(), d.medId)?.active)
    .sort((a, b) => a.scheduledAt - b.scheduledAt)
    .map((d) => viewDose(d, now));
  return { now, patient, doses, week: D.adherence(db(), patient.id, now, 7).last7 };
});

route('GET', '/api/patients/:id/adherence', ({ params }) => {
  if (!getPatient(params.id)) return fail(404, 'Patient not found.');
  return D.adherence(db(), params.id, clock.now(), 14);
});

route('GET', '/api/patients/:id/alerts', ({ params }) => {
  if (!getPatient(params.id)) return fail(404, 'Patient not found.');
  const list = db().alerts.filter((a) => a.patientId === params.id).sort((a, b) => b.at - a.at).slice(0, 60);
  return { now: clock.now(), alerts: list };
});

route('GET', '/api/patients/:id/meds', ({ params }) => {
  if (!getPatient(params.id)) return fail(404, 'Patient not found.');
  return db().meds.filter((m) => m.patientId === params.id && m.active).map(publicMed);
});

route('POST', '/api/patients/:id/meds', ({ params, body }) => {
  if (!getPatient(params.id)) return fail(404, 'Patient not found.');
  const parsed = parseMedication(body);
  if (parsed.error) return fail(400, parsed.error);
  const { photo, removePhoto, ...fields } = parsed.value;
  const med = {
    id: D.newId(), patientId: params.id, ...fields,
    refillAlerted: fields.stock < D.REFILL_BELOW, active: true, photo: photo || null, photoV: photo ? 1 : 0,
  };
  db().meds.push(med);
  D.ensureDoses(db(), dateKey(clock.now()));
  commit();
  return reply(201, publicMed(med));
});

route('PUT', '/api/meds/:id', ({ params, body }) => {
  const med = db().meds.find((m) => m.id === params.id && m.active);
  if (!med) return fail(404, 'Medicine not found.');
  const parsed = parseMedication(body);
  if (parsed.error) return fail(400, parsed.error);
  const { photo, removePhoto, ...fields } = parsed.value;
  Object.assign(med, fields);
  if (photo) { med.photo = photo; med.photoV += 1; }
  else if (removePhoto) { med.photo = null; med.photoV += 1; }
  med.refillAlerted = med.stock < D.REFILL_BELOW ? med.refillAlerted : false;

  // today's unconfirmed doses follow the new schedule; finished ones stay as history
  const today = dateKey(clock.now());
  db().doses = db().doses.filter((d) => !(d.medId === med.id && d.date >= today && d.status === 'pending'));
  D.ensureDoses(db(), today);
  commit();
  return publicMed(med);
});

route('DELETE', '/api/meds/:id', ({ params }) => {
  const med = db().meds.find((m) => m.id === params.id && m.active);
  if (!med) return fail(404, 'Medicine not found.');
  med.active = false;     // soft delete so past adherence still adds up
  const today = dateKey(clock.now());
  db().doses = db().doses.filter((d) => !(d.medId === med.id && d.date >= today && d.status === 'pending'));
  commit();
  return { ok: true };
});

route('GET', '/api/meds/:id/photo', ({ params, res }) => {
  const med = db().meds.find((m) => m.id === params.id);
  const match = med && med.photo && /^data:(image\/[a-z]+);base64,(.+)$/.exec(med.photo);
  if (!match) return fail(404, 'No photo.');
  res.writeHead(200, { 'Content-Type': match[1], 'Cache-Control': 'public, max-age=86400' });
  res.end(Buffer.from(match[2], 'base64'));
  return null;
});

route('POST', '/api/meds/:id/refill', ({ params, body }) => {
  const result = D.refillMed(db(), params.id, body.count, clock.now());
  if (result.error) return fail(result.code, result.error);
  commit();
  return publicMed(result.med);
});

route('POST', '/api/doses/:id/take', ({ params, body }) => {
  const result = D.takeDose(db(), params.id, clock.now(), { selfReported: body.selfReported === true });
  if (result.error) return fail(result.code, result.error);
  commit();
  return { dose: viewDose(result.dose, clock.now()), duplicate: !!result.duplicate };
});

route('POST', '/api/doses/:id/snooze', ({ params }) => {
  const result = D.snoozeDose(db(), params.id, clock.now());
  if (result.error) return fail(result.code, result.error);
  commit();
  return { dose: viewDose(result.dose, clock.now()) };
});

route('POST', '/api/alerts/:id/ack', ({ params }) => {
  const alert = db().alerts.find((a) => a.id === params.id);
  if (!alert) return fail(404, 'Alert not found.');
  alert.ack = true;
  commit();
  return alert;
});

route('POST', '/api/patients/:id/sos', ({ params }) => {
  const patient = getPatient(params.id);
  if (!patient) return fail(404, 'Patient not found.');
  const alert = D.addAlert(db(), { type: 'sos', severity: 'urgent', patientId: patient.id, at: clock.now() });
  dispatch([alert]);
  commit();
  return { alert, caregiver: patient.caregiver, emergencyNumber: patient.emergencyNumber };
});

// ---- demo controls ------------------------------------------------------------

route('POST', '/api/demo/trigger', ({ body }) => {
  const patient = getPatient(body.patientId);
  if (!patient) return fail(404, 'Patient not found.');
  const now = clock.now();
  const today = dateKey(now);
  D.tick(db(), now);

  const mine = db().doses.filter((d) => d.patientId === patient.id && d.date === today);
  let dose = body.doseId ? mine.find((d) => d.id === body.doseId) : null;
  if (!dose) dose = mine.filter((d) => d.status === 'pending').sort((a, b) => a.scheduledAt - b.scheduledAt)[0];
  if (!dose) dose = mine.sort((a, b) => b.scheduledAt - a.scheduledAt)[0];   // everything done: reopen the last one
  if (!dose) return fail(409, 'No doses scheduled today.');

  if (dose.status === 'taken') {
    const med = D.medOf(db(), dose.medId);
    if (med) med.stock += 1;
  }
  dose.status = 'pending';
  dose.takenAt = null;
  dose.onTime = null;
  dose.selfReported = false;
  dose.snoozedUntil = null;
  dose.scheduledAt = now;
  // clear the old trail for this dose so the demo reads cleanly
  db().alerts = db().alerts.filter((a) => !(a.doseId === dose.id));
  commit();
  return viewDose(dose, now);
});

route('POST', '/api/demo/advance', ({ body }) => {
  const minutes = Number(body.minutes);
  if (!Number.isFinite(minutes) || minutes < 1 || minutes > 1440) return fail(400, 'Minutes must be between 1 and 1440.');
  clock.advance(minutes);
  const fresh = D.tick(db(), clock.now());
  dispatch(fresh);
  commit();
  return { now: clock.now(), escalated: fresh.length };
});

route('POST', '/api/demo/reset', () => {
  clock.reset();
  store.reseed(clock.now());
  broadcast();
  return { ok: true, now: clock.now() };
});

// ---- http plumbing ------------------------------------------------------------

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json',
};

function serveStatic(req, res, pathname) {
  const rel = pathname === '/' ? '/index.html' : pathname;
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

function handle(req, res) {
  const url = new URL(req.url, 'http://localhost');

  if (url.pathname === '/api/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write('retry: 2000\n\n');
    listeners.add(res);
    const ping = setInterval(() => res.write(': ping\n\n'), 25000);
    req.on('close', () => { clearInterval(ping); listeners.delete(res); });
    return;
  }

  if (!url.pathname.startsWith('/api/')) {
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    return serveStatic(req, res, decodeURIComponent(url.pathname));
  }

  const match = routes.find((r) => r.method === req.method && r.re.test(url.pathname));
  if (!match) return json(res, 404, { error: 'Unknown endpoint.' });

  const params = { ...match.re.exec(url.pathname).groups };
  const run = req.method === 'GET' || req.method === 'DELETE' ? Promise.resolve({}) : readBody(req);
  run.then((body) => {
    const out = match.handler({ params, body, res });
    if (out === null) return;                       // handler already answered (photo)
    if (out && out[REPLY]) return json(res, out.code, out.payload);
    json(res, 200, out);
  }).catch((err) => {
    if (err.code === 400 || err.code === 413) return json(res, err.code, { error: err.message });
    console.error(err);
    json(res, 500, { error: 'Something went wrong on our side.' });
  });
}

const server = http.createServer(handle);

if (require.main === module) {
  server.listen(PORT, () => {
    console.log(`\n  PillPing is running.\n`);
    console.log(`  Open  http://localhost:${PORT}\n`);
  });
}

module.exports = { server, store, clock };
